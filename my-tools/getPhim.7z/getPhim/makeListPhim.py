import sys
f = open("mylist.txt","w")
print("argument {} - {} ".format(sys.argv[1],sys.argv[2]))
end = int(sys.argv[2])+1;
for x in range(int(sys.argv[1]),end):
	f.write("file 'endless{}.mp4'".format(x))
	f.write("\n")
print("DONE")
f.close()
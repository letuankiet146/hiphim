
function processAsyncActions(iterator) {
  // return a function that accepts the items to be processed
  return (items) => {
    // create an empty results array
    const results = []
    // use Array.reduce to iterate over the array
    return items.reduce((promise, item, idx) => {
      // when the previous promise resolves...
      return promise.then((result) => { 
        // ...add the result to the results array
        if (result) results.push(result)
        // call the iterator function with previous result and the next item
        return iterator(result, item) 
      })
    }, Promise.resolve())
      // finally add the last result to the results and return
      .then((result) => [...results, result])
  }
}

const processList = processAsyncActions(
  // create an iterator function, that does an async "request"
  (previousResult, item) => {
    // do something with the previous result, possibly control the flow, throw an error etc
    console.log(`Processing: ${item}`)
    // make request for next item
    return makeRequest(item)
  }
)

/// demo utils
function randInt() { return 100 + Math.floor(Math.random() * 500) }

function makeRequest(item) {
  return new Promise((resolve, reject) => {
    // const ms = randInt()
    // setTimeout(() => {
    //   resolve({ item: `Record ${item}`, ms })
    // }, ms)   
    var itemUrl = 'https://ohoea007.xyz/hls3/9adbfda06e6671c53404405e2713f62a/9adbfda06e6671c53404405e2713f62a-'+item+'.html?msKey=m3'; 
    var xhr = new XMLHttpRequest();
    var b = document.createElement('a');
    xhr.open('GET', itemUrl, true);
    xhr.responseType = 'blob';
    xhr.onreadystatechange = function() { 
      if(this.status == 200 && this.readyState == 4){
        b.href = window.URL.createObjectURL(xhr.response);
        b.download = "endless"+item+".mp4";
        b.click();
        resolve({ item: `endless ${item}.mp4`})
      }
    };
    xhr.send(); 
  })  
}

// make item list download
videourls =[];
for ( i = 1041 ; i<1829; i++){ 
  videourls.push(i);
} 



// call the with a array of 'things'
processList((videourls))
  .then((allResults) => console.log('All done', allResults))
  .catch((err) => console.log('Something broke'))
